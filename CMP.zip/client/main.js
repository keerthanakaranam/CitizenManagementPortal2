// YOUR JAVASCRIPT CODE FOR INDEX.HTML GOES HERE
// SIDEBAR TOGGLE

let sidebarOpen = false;
const sidebar = document.getElementById('sidebar');

function openSidebar() {
  if (!sidebarOpen) {
    sidebar.classList.add('sidebar-responsive');
    sidebarOpen = true;
  }
}

function closeSidebar() {
  if (sidebarOpen) {
    sidebar.classList.remove('sidebar-responsive');
    sidebarOpen = false;
  }
}

// ---------- CHARTS ----------

// BAR CHART
const barChartOptions = {
  series: [
    {
      data: [10, 8, 6, 4, 2],
    },
  ],
  chart: {
    type: 'bar',
    height: 350,
    toolbar: {
      show: false,
    },
  },
  colors: ['#246dec', '#cc3c43', '#367952', '#f5b74f', '#4f35a1'],
  plotOptions: {
    bar: {
      distributed: true,
      borderRadius: 4,
      horizontal: false,
      columnWidth: '40%',
    },
  },
  dataLabels: {
    enabled: false,
  },
  legend: {
    show: false,
  },
  xaxis: {
    categories: ['Tax Services', 'Transportation', 'Healthcare', 'Education ', 'Employment'],
  },
  yaxis: {
    title: {
      text: 'Count',
    },
  },
};
 
const barChart = new ApexCharts(
  document.querySelector('#bar-chart'),
  barChartOptions
);
barChart.render();

// AREA CHART
const areaChartOptions = {
  series: [
    {
      name: 'No of Voters',
      data: [31, 40, 28, 51, 42, 109, 100],
    },
    {
      name: 'Areas',
      data: [111, 232, 425, 312, 324, 542],
    },
  ],
  chart: {
    height: 350,
    type: 'area',
    toolbar: {
      show: false,
    },
  },
  colors: ['#4f35a1', '#246dec'],
  dataLabels: {
    enabled: false,
  },
  stroke: {
    curve: 'smooth',
  },
  labels: ['Ananthapur','Kurnool','Chittor','Kadapa','Guntur','Vizag'],
  markers: {
    size: 0,
  },
  yaxis: [
    {
      title: {
        text: 'No.of Voters',
      },
    },
    {
      opposite: true,
      title: {
        text: 'Areas',
      },
    },
  ],
  tooltip: {
    shared: true,
    intersect: false,
  },
};

const areaChart = new ApexCharts(
  document.querySelector('#area-chart'),
  areaChartOptions
);
areaChart.render();

function openLink(link) {
  // Fetch the content from the provided link (you can use AJAX or other methods)
  // For simplicity, I'll just replace the content with a simple message
  document.getElementById('content').innerHTML = '<p>This is the content loaded from: ' + link + '</p>';
}