
var request = require('request');
var options = {
  'method': 'POST',
  'url': 'https://www.zohoapis.com/crm/v5/Leads',
  'headers': {
    'Authorization': 'Zoho-oauthtoken 1000.5c84b91ca367616a70b62c9ece37f741.a3c890e5c3f554fce76becb17fe99d11',
    'Content-Type': 'application/json',
    'Cookie': '1a99390653=0361cfa6107f6be32a93b6caa457b5fb; _zcsr_tmp=67a49ff8-d002-4a44-8589-d51d88ebc545; crmcsr=67a49ff8-d002-4a44-8589-d51d88ebc545'
  },
  body: JSON.stringify({
    "data": [
      {
        "Lead_Source": "Employee Referral",
        "Company": "ABC",
        "Last_Name": "Daly",
        "First_Name": "Paul",
        "Email": "p.daly@zylker.com",
        "State": "Texas"
      },
      {
        "Lead_Source": "Trade Show",
        "Company": "ABC",
        "Last_Name": "Dolan",
        "First_Name": "Brian",
        "Email": "brian@villa.com",
        "State": "Texas"
      }
    ],
    "apply_feature_execution": [
      {
        "name": "layout_rules"
      }
    ],
    "trigger": [
      "approval",
      "workflow",
      "blueprint",
      "pathfinder",
      "orchestration"
    ]
  })

};
request(options, function (error, response) {
  if (error) throw new Error(error);
  console.log(response.body);
});